import React from 'react';

class Home extends React.Component {
  render() {
    return <h1>Movies</h1>;
  }
}

export default Home;
